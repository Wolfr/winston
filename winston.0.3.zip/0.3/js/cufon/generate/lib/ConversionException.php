<?php

class ConversionException extends RuntimeException {
}